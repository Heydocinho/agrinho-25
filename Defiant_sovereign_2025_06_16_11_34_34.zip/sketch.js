let personagem;
let chaoY;
let itensColetaveis = [];
let obstaculos = [];
let pontuacao = 0;
let luzesAcesas = 0; // Quantas luzes estão acesas
let totalLuzes = 20; // Número total de luzes para acender

// Imagens (você precisará criar ou encontrar)
let imgPersonagem;
let imgMilho;
let imgFogueira;
let imgBandeirinha;
let imgPipa;
let imgChaoCampo;
let imgChaoCidade;
let imgPredio;
let imgTrator;
let imgCarro;

function preload() {
  // Carregar imagens aqui
  // imgPersonagem = loadImage('caminho/para/personagem.png');
  // imgMilho = loadImage('caminho/para/milho.png');
  // ... e assim por diante
}

function setup() {
  createCanvas(800, 400); // Largura e altura do canvas
  chaoY = height - 50; // Posição Y do chão

  personagem = {
    x: width / 4,
    y: chaoY,
    largura: 30,
    altura: 50,
    velocidadeY: 0,
    gravidade: 0.5,
    pulando: false
  };

  // Fogueira (posição fixa)
  // Pode ser um objeto com x, y, largura, altura
  fogueira = { x: 100, y: chaoY - 40, largura: 50, altura: 50 };

  // Bandeirinhas (pode ser uma array de objetos ou desenhadas em loop)
  // Exemplo: desenhar bandeirinhas em um loop no draw()

  // Gerar alguns itens iniciais e obstáculos
  // setInterval(gerarItem, 2000); // Gera um item a cada 2 segundos
  // setInterval(gerarObstaculo, 3000); // Gera um obstáculo a cada 3 segundos
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Desenhar o cenário (campo e cidade)
  desenharCenario();

  // Desenhar elementos fixos (fogueira, bandeirinhas)
  desenharFogueira();
  desenharBandeirinhas();
  desenharLuzes(); // Desenha as luzes da festa

  // Atualizar e desenhar personagem
  atualizarPersonagem();
  desenharPersonagem();

  // Atualizar e desenhar itens coletáveis
  for (let i = itensColetaveis.length - 1; i >= 0; i--) {
    let item = itensColetaveis[i];
    item.x -= 2; // Move o item para a esquerda
    desenharItem(item);

    // Verificar colisão com o personagem
    if (colisao(personagem, item)) {
      pontuacao += 10;
      luzesAcesas = min(luzesAcesas + 1, totalLuzes); // Acende uma luz, limitado ao total
      itensColetaveis.splice(i, 1); // Remove o item coletado
    }

    // Remover itens fora da tela
    if (item.x < -item.largura) {
      itensColetaveis.splice(i, 1);
    }
  }

  // Atualizar e desenhar obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    let obstaculo = obstaculos[i];
    obstaculo.x -= 3; // Move o obstáculo para a esquerda (mais rápido que os itens)
    desenharObstaculo(obstaculo);

    // Verificar colisão com o personagem
    if (colisao(personagem, obstaculo)) {
      // Lógica para perder vida/pontos
      // Por enquanto, apenas remove o obstáculo
      obstaculos.splice(i, 1);
      print("Colidiu com obstáculo!");
      // Aqui você adicionaria lógica para GAME OVER ou perda de vida
    }

    // Remover obstáculos fora da tela
    if (obstaculo.x < -obstaculo.largura) {
      obstaculos.splice(i, 1);
    }
  }

  // Display de pontuação
  fill(0);
  textSize(20);
  text("Pontuação: " + pontuacao, 10, 30);

  // Geração de itens e obstáculos (pode ser mais sofisticado com temporizadores)
  if (frameCount % 120 == 0) { // A cada 2 segundos (60 fps * 2)
    gerarItem();
  }
  if (frameCount % 180 == 0) { // A cada 3 segundos
    gerarObstaculo();
  }
}

function keyPressed() {
  if (keyCode === UP_ARROW && !personagem.pulando) {
    personagem.velocidadeY = -10; // Força do pulo
    personagem.pulando = true;
  }
}

function atualizarPersonagem() {
  personagem.velocidadeY += personagem.gravidade;
  personagem.y += personagem.velocidadeY;

  // Evitar que o personagem caia abaixo do chão
  if (personagem.y >= chaoY - personagem.altura) {
    personagem.y = chaoY - personagem.altura;
    personagem.velocidadeY = 0;
    personagem.pulando = false;
  }
}

function desenharPersonagem() {
  fill(255, 0, 0); // Cor de exemplo para o personagem
  rect(personagem.x, personagem.y, personagem.largura, personagem.altura);
  // image(imgPersonagem, personagem.x, personagem.y, personagem.largura, personagem.altura);
}

function desenharCenario() {
  // Campo
  fill(100, 200, 70); // Verde para o campo
  rect(0, chaoY, width / 2, height - chaoY);
  // image(imgChaoCampo, 0, chaoY, width / 2, height - chaoY);

  // Cidade
  fill(150, 150, 150); // Cinza para a cidade
  rect(width / 2, chaoY, width / 2, height - chaoY);
  // image(imgChaoCidade, width / 2, chaoY, width / 2, height - chaoY);

  // Desenhar alguns prédios na cidade
  fill(180, 180, 180);
  rect(width * 0.6, chaoY - 80, 40, 80);
  rect(width * 0.75, chaoY - 120, 50, 120);
  // image(imgPredio, ..., ...);
}

function desenharFogueira() {
  fill(255, 100, 0); // Laranja para a fogueira
  ellipse(fogueira.x, fogueira.y + fogueira.altura / 2, fogueira.largura, fogueira.altura);
  fill(255, 200, 0); // Amarelo para o fogo
  ellipse(fogueira.x, fogueira.y, fogueira.largura * 0.7, fogueira.altura * 0.7);
  // image(imgFogueira, fogueira.x, fogueira.y, fogueira.largura, fogueira.altura);
}

function desenharBandeirinhas() {
  let numBandeirinhas = 15;
  let espacamento = width / numBandeirinhas;
  let alturaInicial = 50;
  let amplitudeBalanco = 10;
  let velocidadeBalanco = 0.05;

  for (let i = 0; i < numBandeirinhas; i++) {
    let x = i * espacamento + espacamento / 2;
    let y = alturaInicial + sin(frameCount * velocidadeBalanco + i) * amplitudeBalanco;
    fill(random(255), random(255), random(255)); // Cores aleatórias para as bandeirinhas
    triangle(x, y, x - 10, y + 20, x + 10, y + 20); // Forma de bandeirinha
    // image(imgBandeirinha, x, y, 20, 20); // Se tiver uma imagem
  }
}

function desenharLuzes() {
  let numLuzesPorFio = totalLuzes / 2; // Exemplo: 2 fios de luzes
  let espacamentoLuzes = (width / 2) / numLuzesPorFio;
  let alturaLuzes = 80;

  // Fio 1 (campo)
  for (let i = 0; i < numLuzesPorFio; i++) {
    let x = i * espacamentoLuzes + espacamentoLuzes / 2;
    let y = alturaLuzes;
    if (i < luzesAcesas / 2) { // Acende as luzes do primeiro fio
      fill(255, 255, 0); // Amarelo para luz acesa
    } else {
      fill(50); // Cinza para luz apagada
    }
    ellipse(x, y, 10, 10);
  }

  // Fio 2 (cidade)
  for (let i = 0; i < numLuzesPorFio; i++) {
    let x = (width / 2) + (i * espacamentoLuzes + espacamentoLuzes / 2);
    let y = alturaLuzes;
    if (i < (luzesAcesas - numLuzesPorFio) / 2) { // Acende as luzes do segundo fio
      fill(255, 255, 0);
    } else {
      fill(50);
    }
    ellipse(x, y, 10, 10);
  }
}


function gerarItem() {
  let tipoItem = floor(random(3)); // 0: milho, 1: pipoca, 2: bolo
  let item = {
    x: width,
    y: random(chaoY - 80, chaoY - 20), // Altura aleatória acima do chão
    largura: 20,
    altura: 20,
    tipo: tipoItem
  };
  itensColetaveis.push(item);
}

function desenharItem(item) {
  switch (item.tipo) {
    case 0: // Milho
      fill(255, 255, 0);
      ellipse(item.x, item.y, item.largura, item.altura * 2); // Forma de espiga
      // image(imgMilho, item.x, item.y, item.largura, item.altura);
      break;
    case 1: // Pipoca
      fill(255, 255, 255);
      rect(item.x, item.y, item.largura, item.altura); // Forma de saquinho
      // image(imgPipoca, item.x, item.y, item.largura, item.altura);
      break;
    case 2: // Bolo de Fubá
      fill(200, 150, 50);
      triangle(item.x, item.y, item.x + item.largura, item.y, item.x + item.largura / 2, item.y + item.altura); // Forma de fatia
      // image(imgBoloFuba, item.x, item.y, item.largura, item.altura);
      break;
  }
}

function gerarObstaculo() {
  let tipoObstaculo = floor(random(3)); // 0: balao, 1: trator, 2: carro
  let obstaculo = {
    x: width,
    largura: 40,
    altura: 40,
    tipo: tipoObstaculo
  };

  if (tipoObstaculo === 0) { // Balao (no alto)
    obstaculo.y = random(50, height / 2);
  } else { // Trator ou Carro (no chão)
    obstaculo.y = chaoY - obstaculo.altura;
  }
  obstaculos.push(obstaculo);
}

function desenharObstaculo(obstaculo) {
  switch (obstaculo.tipo) {
    case 0: // Balao
      fill(255, 0, 255);
      ellipse(obstaculo.x, obstaculo.y, obstaculo.largura, obstaculo.altura * 1.2); // Forma de balão
      // image(imgBalao, obstaculo.x, obstaculo.y, obstaculo.largura, obstaculo.altura);
      break;
    case 1: // Trator
      fill(0, 100, 0);
      rect(obstaculo.x, obstaculo.y, obstaculo.largura, obstaculo.altura); // Forma de trator
      // image(imgTrator, obstaculo.x, obstaculo.y, obstaculo.largura, obstaculo.altura);
      break;
    case 2: // Carro
      fill(100, 100, 100);
      rect(obstaculo.x, obstaculo.y, obstaculo.largura, obstaculo.altura * 0.7); // Forma de carro
      // image(imgCarro, obstaculo.x, obstaculo.y, obstaculo.largura, obstaculo.altura);
      break;
  }
}

// Função de colisão simples (AABB - Axis-Aligned Bounding Box)
function colisao(obj1, obj2) {
  return obj1.x < obj2.x + obj2.largura &&
         obj1.x + obj1.largura > obj2.x &&
         obj1.y < obj2.y + obj2.altura &&
         obj1.y + obj1.altura > obj2.y;
}